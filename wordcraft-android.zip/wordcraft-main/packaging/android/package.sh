#!/usr/bin/env bash
# Builds the Android package (APK): the Rust library for each ABI with cargo-ndk, then the
# Gradle project in apps/wordcraft-android/android around it.
#
# Needs: the Android SDK (ANDROID_HOME) with a platform and build tools for API 35, the NDK
# (ANDROID_NDK_HOME), a JDK 17 or later, Gradle 8.9 or later, `cargo install cargo-ndk`, and
# the Rust targets: `rustup target add aarch64-linux-android x86_64-linux-android`.
#
# Environment:
#   WORDCRAFT_ANDROID_ABIS      ABIs to build, space separated (default: "arm64-v8a x86_64";
#                               x86_64 is for emulators; add armeabi-v7a for old 32-bit phones)
#   WORDCRAFT_ANDROID_VARIANT   debug (default: signed with the SDK's debug key, installs with
#                               `adb install`) or release (signed when WORDCRAFT_ANDROID_KEYSTORE,
#                               _KEYSTORE_PASSWORD and _KEY_ALIAS name a key; unsigned otherwise)
#   CRAFT_I18N_DIR              a craft-i18n checkout, for the translations and proofing data
set -euo pipefail

. "$(dirname "$0")/../env.sh"

PROJECT="$ROOT/apps/wordcraft-android/android"
JNI_LIBS="$PROJECT/app/src/main/jniLibs"
VARIANT="${WORDCRAFT_ANDROID_VARIANT:-debug}"
read -r -a ABIS <<<"${WORDCRAFT_ANDROID_ABIS:-arm64-v8a x86_64}"

case "$VARIANT" in
  debug) TASK=assembleDebug ;;
  release) TASK=assembleRelease ;;
  *)
    echo "error: WORDCRAFT_ANDROID_VARIANT must be debug or release, got '$VARIANT'" >&2
    exit 1
    ;;
esac
if ! cargo ndk --version >/dev/null 2>&1; then
  echo "error: cargo-ndk is not installed: cargo install cargo-ndk" >&2
  exit 1
fi
if [[ -z "${ANDROID_NDK_HOME:-}" && -z "${ANDROID_HOME:-}" ]]; then
  echo "error: set ANDROID_HOME (the SDK) and ANDROID_NDK_HOME (the NDK)" >&2
  exit 1
fi

TARGETS=()
for abi in "${ABIS[@]}"; do
  TARGETS+=(--target "$abi")
done

# Libraries of an earlier build for ABIs no longer asked for must not end up in the package.
rm -rf "$JNI_LIBS"
# The optimized library in either variant: a debug build of the layout engine is too slow to use.
# --platform is the lowest Android release the library runs on (minSdk in app/build.gradle.kts).
(cd "$ROOT" && cargo ndk "${TARGETS[@]}" --platform 24 --output-dir "$JNI_LIBS" build --release -p wordcraft-android)

GRADLE="gradle"
if [[ -x "$PROJECT/gradlew" ]]; then
  GRADLE="$PROJECT/gradlew"
fi
"$GRADLE" -p "$PROJECT" "$TASK"

APK="$(find "$PROJECT/app/build/outputs/apk/$VARIANT" -name '*.apk' | head -n 1)"
if [[ -z "$APK" ]]; then
  echo "error: Gradle finished without an APK under $PROJECT/app/build/outputs/apk/$VARIANT" >&2
  exit 1
fi
OUT="$DIST/wordcraft-$VERSION-android-$VARIANT.apk"
cp -f "$APK" "$OUT"
echo "$OUT"
